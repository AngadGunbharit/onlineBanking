package com.cg;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


/**
 * @author Angad Gunbharit
 *
 */
@RestController
public class AccountHolderController {

	@Autowired
	AccountHolderJpa repo;
		
	@GetMapping(path="/all-accountholder")
	
	public List<AccountHolder> getAllAccountHolder()
	
	{
		System.out.println("Inside Get  all account holder method");
		return repo.findAll();
	}
	@GetMapping(path="/accholder/{name}")
	public AccountHolder getAccountHolderByName(@PathVariable String name)
	{
		System.out.println("Inside the AccountHolder Get by Name method ");
		AccountHolder accountHolder = repo. findByAccountHolderName( name);
		System.out.println("returned Account Holder " + accountHolder);
		return accountHolder;
	
	}

	@PostMapping(path = "/add-accholder")

	public void addProducts(@Valid @RequestBody AccountHolder accountHolder) {
		System.out.println("Inside Add AccountHolders");
		repo.save(accountHolder);
	}
	@DeleteMapping(path = "/delete-AccountHolder/{id}")
	
	public void deleteProduct(String accHolderId) {
		repo.deleteById(accHolderId);
	}

	@PutMapping(path = "/update-AccountHolder")
	
	public void updateProduct(@RequestBody AccountHolder accountHolder) {
		System.out.println("Inside Update AccountHolders ");
		repo.deleteById(accountHolder.getAccHolderId());
		repo.save(accountHolder);
	}
	
	
	
	
//
//	@GetMapping(path = "/listofproducts")
//	//@HystrixCommand(fallbackMethod = "getAllProducts"
//	public List<AccountHolder> getAllAccountHolders() {
//		System.out.println("Inside get All AccountHolders");
//		System.out.println("Calling to fallbackMethod = \"getAllAccountHolder\"");
//		throw new RuntimeException("Not Available");
//	}
//
	

}
