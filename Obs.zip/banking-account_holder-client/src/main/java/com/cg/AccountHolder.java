package com.cg;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "AccountHolder")
public class AccountHolder {

	@Id
	private String accHolderId;
	@Column
	private String name;
	@Column
	private String mobile;
	@Column
	private String address;
	@Column
	private String password;
	@Column
	private String panCard;
	@Column
	private String email;
	
	
	
	public String getAccHolderId() {
		return accHolderId;
	}
	public void setAccHolderId(String accHolderId) {
		this.accHolderId = accHolderId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getPanCard() {
		return panCard;
	}
	public void setPanCard(String panCard) {
		this.panCard = panCard;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@Override
	public String toString() {
		return "AccountHolder [accHolderId=" + accHolderId + ", name=" + name + ", mobile=" + mobile + ", address="
				+ address + ", password=" + password + ", panCard=" + panCard + ", email=" + email + "]";
	}
	public AccountHolder(String accHolderId, String name, String mobile, String address, String password,
			String panCard, String email) {
		super();
		this.accHolderId = accHolderId;
		this.name = name;
		this.mobile = mobile;
		this.address = address;
		this.password = password;
		this.panCard = panCard;
		this.email = email;
	}
	public AccountHolder() {
		super();
		// TODO Auto-generated constructor stub
	}

}
