package com.cg;

import org.springframework.data.jpa.repository.JpaRepository;

public interface AccountJpaRepo extends JpaRepository{

	
	
}
