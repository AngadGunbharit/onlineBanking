package com.cg;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Account")
public class Account {
	@Id
	//@GeneratedValue(strategy = GenerationType.AUTO)
	private String accNum;
	@Column
	
	private AccountType type;
	@Column
	private double openingBalance;
	@Column
	private double balance;
	@Enumerated
	private Status stat;
	@Column
	private String acHolderId;
	@Enumerated
	private String remarks;
	public String getAccNum() {
		return accNum;
	}
	public void setAccNum(String accNum) {
		this.accNum = accNum;
	}
	public AccountType getType() {
		return type;
	}
	public void setType(AccountType type) {
		this.type = type;
	}
	public double getOpeningBalance() {
		return openingBalance;
	}
	public void setOpeningBalance(double openingBalance) {
		this.openingBalance = openingBalance;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public Status getStat() {
		return stat;
	}
	public void setStat(Status stat) {
		this.stat = stat;
	}
	public String getAcHolderId() {
		return acHolderId;
	}
	public void setAcHolderId(String acHolderId) {
		this.acHolderId = acHolderId;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public Account(String accNum, AccountType type, double openingBalance, double balance, Status stat,
			String acHolderId, String remarks) {
		super();
		this.accNum = accNum;
		this.type = type;
		this.openingBalance = openingBalance;
		this.balance = balance;
		this.stat = stat;
		this.acHolderId = acHolderId;
		this.remarks = remarks;
	}
	public Account() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Account [accNum=" + accNum + ", type=" + type + ", openingBalance=" + openingBalance + ", balance="
				+ balance + ", stat=" + stat + ", acHolderId=" + acHolderId + ", remarks=" + remarks + "]";
	}

}
