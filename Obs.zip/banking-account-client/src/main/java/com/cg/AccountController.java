package com.cg;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AccountController {

	@Autowired
	AccountJpaRepo repo;

	@GetMapping(path = "/All_accounts")
	public List<Account> getAllAccounts() {
		System.out.println("Inside All accounts method ");
		return new ArrayList<Account>();

	}

	@GetMapping(path = "/account/{accountno}")
	public Account getByAccountName(@PathVariable String accountNum) {
		System.out.println("Inside the Product Get by Name method ");

		return new Account();

	}
	
	@GetMapping(path="/accounts/pendinglist")
	public List<Account>listAllPendingAccounts()
	{
	
		return new ArrayList<Account>();
		
	}
	
	
}
