package com.cg;

public enum Status {
	Pending,Rejected,Approved;
	}