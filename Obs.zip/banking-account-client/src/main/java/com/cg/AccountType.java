package com.cg;





public enum AccountType {
	Savings,Current;
}
